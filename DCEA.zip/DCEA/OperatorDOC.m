function Offspring = OperatorDOC(Problem,Parent1,Parent3,K,S)

%% Parameter setting
[proM,disM] = deal(0.3,30);
Parent1 = Parent1.decs;
P3obj = Parent3.objs;
Parent3 = Parent3.decs;
[N,D]   = size(Parent1);
Lower = repmat(Problem.lower,N,1);
Upper = repmat(Problem.upper,N,1);
OffDeca = [];
for k = 1:K
    P1 = Parent1(S*(k-1)+1:k*S,:);
    P3 = Parent3(S*(k-1)+1:k*S,:);
    PO3 = P3obj(S*(k-1)+1:k*S,:);
    FrontNo    = NDSort(PO3,inf);
    if max(FrontNo) > 1
        for i = 1 : S   
            r1 = Problem.FE/Problem.maxFE + 1;  
            r2 = (2*pi)*rand();
            r3 = 2*rand();
            beta = 1-(Problem.FE/Problem.maxFE)^0.5;
            if rand() < 0.5
                Offtemp(i,:) = P3(i,:)+ r1*sin(r2)*abs(r3*P1(i,:) - P3(i,:)); 
            else
                Offtemp(i,:) = P3(i,:)+ r1*cos(r2)*abs(r3*P1(i,:) - P3(i,:)); 
            end
            OffDec(i,:) = Offtemp(i,:) + beta * (P1(i,:) - P3(i,:));
        end
    else
        for i = 1 : S
            r1 = 1 - Problem.FE/Problem.maxFE; 
            r2 = (2*pi)*rand();
            r3 = 2*rand();
            beta = 1-(Problem.FE/Problem.maxFE)^0.5;
            if rand() < 0.5
                Offtemp(i,:) = P3(i,:)+ r1*sin(r2)*abs(r3*P1(i,:) - P3(i,:));
            else
                Offtemp(i,:) = P3(i,:)+ r1*cos(r2)*abs(r3*P1(i,:) - P3(i,:));
            end
            OffDec(i,:) = Offtemp(i,:) + beta * (P1(i,:) - P3(i,:));
        end
    end
    OffDeca = [OffDeca;OffDec];
end

Site  = rand(N,D) < proM/D;
mu   =  rand(N,D);
temp  = Site & mu<=0.5;
OffDeca       = min(max(OffDeca,Lower),Upper);
OffDeca(temp) = OffDeca(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*(1-(OffDeca(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
temp = Site & mu > 0.5;
OffDeca(temp) = OffDeca(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*(1-(Upper(temp)-OffDeca(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));


%% Set the infeasible decision variables to feasible values
temp1 = OffDeca < Lower;
temp2 = OffDeca > Upper;
rnd   = rand(N,D);
OffDeca(temp1) = Lower(temp1) + 0.5*rnd(temp1).*(Parent1(temp1)-Lower(temp1));
OffDeca(temp2) = Upper(temp2) - 0.5*rnd(temp2).*(Upper(temp2)-Parent1(temp2));
Offspring     = Problem.Evaluation(OffDeca);
end
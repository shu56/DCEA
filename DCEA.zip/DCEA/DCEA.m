classdef DCEA < ALGORITHM
    % <multi> <real/integer>
    % K --- 10 --- Number of reference vectors

    %------------------------------- Reference --------------------------------
    % W. Zheng, Y. Tan, Z. Yan, M. Yang, A novel clustering-based evolutionary algorithm with 
    % objective space decomposition for multi/many-objective optimization, Information Sciences 677 (2024) 120940.
    % Platemo version: 4.6


    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            K = Algorithm.ParameterSet(10);

            %% Generate random population
            [W,K]      = UniformPoint(K,Problem.M);
            Problem.N  = ceil(Problem.N/K)*K;
            S          = Problem.N/K;
            Population = Problem.Initialization();
            idealPoint = min(Population.objs,[],1);%calculate ideal point
            Population = Associate(Population,W,S,idealPoint);
            [wn,~] = size(W);
            SC = [];
            %% Optimization
            while Algorithm.NotTerminated(Population)
                PO = Population.objs;
                [T,C] = kmeans(PO,K,'Distance','sqeuclidean','MaxIter',100);
                SC = [SC;C];
                V  = zeros(K,wn);
                for j = 1:K
                    for k = 1:wn
                        V(j,k) = dot(C(j,:),W(k,:))/(norm(C(j,:))*norm(W(k,:)));
                    end
                end
                [~,minp] = min(1-V,[],2);
                MatingPoolLocal0  =  randi(S,S,K) + repmat(0:S:S*(K-1),S,1);
                MatingPoolLocal = zeros(K,S);
                MatingPoolLocal1 = zeros(K,S);
                MatingPoolGlobal     = randi(Problem.N,1,Problem.N);
                for  i = 1:K
                    conT = find(T(:) == minp(i));
                    numT = length(conT);
                    if numT < S
                        MatingPoolLocal(i,1:numT) = conT(randi(numT,numT,1))';
                        MatingPoolLocal(i,numT+1:S)  =   [MatingPoolLocal0(S*(i-1)+numT+1:i*S)];
                        MatingPoolLocal1(i,1:numT) = conT(randi(numT,numT,1))';
                        MatingPoolLocal1(i,numT+1:S)  =  [MatingPoolGlobal(S*(i-1)+numT+1:i*S)];
                    elseif numT == S
                        MatingPoolLocal(i,:) = conT(randi(numT,numT,1))';
                        MatingPoolLocal1(i,:) = conT(randi(numT,numT,1))';
                    else
                        MatingPoolLocal(i,:) = conT(randi(numT,S,1))';
                        MatingPoolLocal1(i,:) = conT(randi(numT,S,1))';
                    end

                end
                Offspring  = OperatorDOC(Problem,Population(MatingPoolLocal(:)),Population(MatingPoolLocal1(:)),K,S);
                if mod(Problem.FE,10000) == 0 && Problem.FE < Problem.maxFE
                    SC = SC(end-99:end, :);
                    numSC = length(SC);
                    VS  = zeros(numSC,K);
                    for v = 1:numSC
                        for s = 1:K
                            VS(v,s) = dot(SC(v,:),W(s,:))/(norm(SC(v,:))*norm(W(s,:)));
                        end
                    end
                    [~,minv] = min(1-VS,[],2);
                    for w = 1:K
                       tempw = find(minv == w);
                       SI = SC(tempw,:);
                       W(w,:) = mean(SI);
                    end
                    SC = [];
                end
                Population = AssociateOC1([Population,Offspring],W,S,idealPoint);
                idealPoint = min(Population.objs,[],1);
            end
        end
    end
end
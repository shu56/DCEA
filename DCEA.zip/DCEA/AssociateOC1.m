function Population = AssociateOC1(Population,W,S,Z)
% Allocation of solutions to subproblems

K = size(W,1);

PO = Population.objs;
[N, M]=size(PO);
[WO,K] = UniformPoint(K,M);
[WA,~] = UniformPoint(N,M);
%% Transformation
%POt = PO - repmat(Z,N,1);
%% Allocation of solutions to subproblems
[~,transformationWA] = max(1-pdist2(PO,WA,'cosine'),[],2);
[~,transformationW] = max(1-pdist2(PO,W,'cosine'),[],2);
B = pdist2(WA,WA);
[~,B] = sort(B,2);
if M == 2
    NB = 10;
else
    NB = 15;
end
B = B(:,1:NB);
rowIndices = zeros(NB, 1);
for w = 1:K
    distances = pdist2(WA, WO(w, :));
    [~, index] = min(distances);
    rowIndices(w) = index;
end
partition = zeros(S,K);
% Allocation
for i = 1 : K
    current = find(transformationW==i);
    if length(current) < S
        currentWA = [];
        BA = B(rowIndices(i),:);
        for j = 1:length(BA)
            currenttemp = find(transformationWA == j);
            currentWA = [currentWA;currenttemp];
        end
        DC = setdiff(currentWA, current);
        if length(DC) > S-length(current)
            Dindex = randperm(length(DC),S-length(current));
            current = [current;DC(Dindex)];
        else
            current = [current;randi(length(Population),S-length(current),1)];
        end
       
    elseif length(current) > S
        % Delete solutions from the current subproblem by non-dominated
        % sorting and crowding distance
        [FrontNo,MaxFNo] = NDSort(Population(current).objs,S);
        Last = find(FrontNo==MaxFNo);
        CrowdDis = CrowdingDistance(Population(current(Last)).objs);
        [~,rank] = sort(CrowdDis);
        FrontNo(Last(rank(1:sum(FrontNo<=MaxFNo)-S))) = inf;
        current = current(FrontNo<=MaxFNo);
    end
    partition(:,i) = current;
end
Population = Population(partition(:));
end